from pathlib import Path
import json
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from classifier.tfidf_classifier import TfidfIntentClassifier

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "Dev Data.csv"
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)


def main():
    df = pd.read_csv(DATA)
    train, test = train_test_split(
        df,
        test_size=0.25,
        random_state=42,
        stratify=df["label_text"],
    )
    classifier = TfidfIntentClassifier(train.reset_index(drop=True))
    predictions = [classifier.predict(q, top_k=5)["predicted_intent"] for q in test["text"]]
    y_true = test["label_text"].tolist()

    print(f"Accuracy: {accuracy_score(y_true, predictions):.4f}")
    print("\nClassification report:")
    print(classification_report(y_true, predictions, zero_division=0))

    report = classification_report(y_true, predictions, output_dict=True, zero_division=0)
    with open(RESULTS / "classification_report.json", "w") as f:
        json.dump(report, f, indent=2)

    labels = sorted(df["label_text"].unique())
    cm = confusion_matrix(y_true, predictions, labels=labels)
    pd.DataFrame(cm, index=labels, columns=labels).to_csv(RESULTS / "confusion_matrix.csv")


if __name__ == "__main__":
    main()
