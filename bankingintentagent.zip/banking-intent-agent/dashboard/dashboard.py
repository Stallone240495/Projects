import pandas as pd
import plotly.express as px
import streamlit as st


def render_dashboard(history: pd.DataFrame, training_df: pd.DataFrame):
    st.subheader("Intent Volume Dashboard")
    if history.empty:
        st.info("No live classifications yet. Classify some customer questions first.")
        return

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Queries", len(history))
    c2.metric("Unique Intents", history["predicted_intent"].nunique())
    c3.metric("Avg Confidence", f"{history['confidence_score'].mean():.1%}")
    c4.metric("Human Review", int(history["low_confidence"].sum()))

    volume = history["predicted_intent"].value_counts().reset_index()
    volume.columns = ["intent", "count"]
    fig = px.bar(volume, x="count", y="intent", orientation="h", title="Live Intent Volume")
    st.plotly_chart(fig, use_container_width=True)

    queue = history["suggested_routing_queue"].value_counts().reset_index()
    queue.columns = ["queue", "count"]
    fig2 = px.pie(queue, names="queue", values="count", title="Routing Queue Distribution")
    st.plotly_chart(fig2, use_container_width=True)

    conf = px.histogram(history, x="confidence_score", nbins=10, title="Confidence Distribution")
    st.plotly_chart(conf, use_container_width=True)

    st.subheader("Training Dataset Intent Distribution")
    train_volume = training_df["label_text"].value_counts().reset_index()
    train_volume.columns = ["intent", "count"]
    st.dataframe(train_volume, use_container_width=True, hide_index=True)
