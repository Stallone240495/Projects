from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class TfidfIntentClassifier:
    """Simple, fast, explainable baseline using TF-IDF + cosine similarity."""

    def __init__(self, df: pd.DataFrame):
        self.df = df.reset_index(drop=True).copy()
        self.vectorizer = TfidfVectorizer(
            lowercase=True,
            ngram_range=(1, 2),
            min_df=1,
            sublinear_tf=True,
            strip_accents="unicode",
        )
        self.matrix = self.vectorizer.fit_transform(self.df["text"])

    def predict(self, question: str, top_k: int = 5) -> dict:
        if not question or not question.strip():
            raise ValueError("Question cannot be empty")

        q = self.vectorizer.transform([question.strip()])
        similarities = cosine_similarity(q, self.matrix).ravel()
        top_indices = np.argsort(similarities)[::-1][:top_k]

        # Aggregate evidence by intent: strongest examples matter most.
        intent_scores: dict[str, list[float]] = {}
        for idx in top_indices:
            intent = self.df.iloc[idx]["label_text"]
            intent_scores.setdefault(intent, []).append(float(similarities[idx]))

        # Weighted score: strongest match + supporting matches.
        ranked = []
        for intent, scores in intent_scores.items():
            scores = sorted(scores, reverse=True)
            score = scores[0] + 0.20 * sum(scores[1:])
            ranked.append((intent, min(score, 1.0)))
        ranked.sort(key=lambda x: x[1], reverse=True)

        predicted_intent, confidence = ranked[0]
        examples = [
            {
                "text": self.df.iloc[i]["text"],
                "intent": self.df.iloc[i]["label_text"],
                "similarity": round(float(similarities[i]), 4),
            }
            for i in top_indices
        ]

        return {
            "predicted_intent": predicted_intent,
            "confidence_score": round(float(confidence), 4),
            "examples": examples,
            "ranked_intents": [
                {"intent": i, "score": round(float(s), 4)} for i, s in ranked[:5]
            ],
        }
