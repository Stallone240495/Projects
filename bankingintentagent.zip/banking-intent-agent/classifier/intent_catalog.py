import pandas as pd
from pathlib import Path


def load_dataset(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"text", "label", "label_text"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing columns: {sorted(missing)}")
    df = df.dropna(subset=["text", "label_text"]).copy()
    df["text"] = df["text"].astype(str).str.strip()
    df["label_text"] = df["label_text"].astype(str).str.strip()
    return df


def get_intents(df: pd.DataFrame) -> list[str]:
    return sorted(df["label_text"].unique().tolist())
