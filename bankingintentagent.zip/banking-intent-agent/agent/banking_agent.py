from __future__ import annotations

import os
from typing import Optional

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

from agent.prompts import SYSTEM_PROMPT
from agent.schemas import IntentClassification
from classifier.tfidf_classifier import TfidfIntentClassifier
from routing.routing_rules import get_queue

load_dotenv()


class BankingIntentAgent:
    def __init__(self, df, use_llm: Optional[bool] = None):
        self.df = df
        self.tfidf = TfidfIntentClassifier(df)
        self.intents = sorted(df["label_text"].unique().tolist())
        if use_llm is None:
            use_llm = os.getenv("USE_LLM", "true").lower() == "true"
        self.use_llm = use_llm and bool(os.getenv("OPENAI_API_KEY"))
        self.llm = None
        if self.use_llm:
            self.llm = ChatOpenAI(
                model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
                temperature=0,
            ).with_structured_output(IntentClassification)

    def classify(self, question: str, top_k: int = 5) -> dict:
        question = question.strip()
        if not question:
            raise ValueError("Customer question cannot be empty")

        baseline = self.tfidf.predict(question, top_k=top_k)

        if self.llm is not None:
            examples_text = "\n".join(
                f'- Example: "{e["text"]}" -> {e["intent"]} (similarity={e["similarity"]})'
                for e in baseline["examples"]
            )
            allowed = ", ".join(self.intents)
            prompt = f"""{SYSTEM_PROMPT}

Allowed intents:
{allowed}

Retrieved examples:
{examples_text}

Customer question:
{question}

Classify the question. Return only the requested structured fields.
"""
            try:
                result = self.llm.invoke(prompt)
                intent = result.predicted_intent
                if intent not in self.intents:
                    intent = baseline["predicted_intent"]
                    confidence = baseline["confidence_score"]
                    reasoning = "LLM returned an invalid intent; used the deterministic classifier."
                else:
                    confidence = float(result.confidence_score)
                    reasoning = result.reasoning
                classifier_name = "LangChain + TF-IDF retrieval"
            except Exception as exc:
                intent = baseline["predicted_intent"]
                confidence = baseline["confidence_score"]
                reasoning = f"LLM unavailable; deterministic classifier used. ({type(exc).__name__})"
                classifier_name = "TF-IDF fallback"
        else:
            intent = baseline["predicted_intent"]
            confidence = baseline["confidence_score"]
            reasoning = "Predicted from TF-IDF similarity against labelled training examples."
            classifier_name = "TF-IDF"

        threshold = float(os.getenv("CONFIDENCE_THRESHOLD", "0.65"))
        queue = get_queue(intent) if confidence >= threshold else "General Support / Human Review"

        return {
            "customer_question": question,
            "predicted_intent": intent,
            "confidence_score": round(confidence, 4),
            "suggested_routing_queue": queue,
            "reasoning": reasoning,
            "classifier": classifier_name,
            "low_confidence": confidence < threshold,
            "retrieved_examples": baseline["examples"],
            "top_intents": baseline["ranked_intents"],
        }
