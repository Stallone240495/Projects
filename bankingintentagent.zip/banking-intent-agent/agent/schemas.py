from typing import Literal
from pydantic import BaseModel, Field


class IntentClassification(BaseModel):
    predicted_intent: str = Field(description="One of the allowed banking intents")
    confidence_score: float = Field(ge=0.0, le=1.0)
    reasoning: str = Field(description="Short explanation based on the customer question and examples")


class ClassificationResult(BaseModel):
    customer_question: str
    predicted_intent: str
    confidence_score: float
    suggested_routing_queue: str
    reasoning: str
    classifier: str
