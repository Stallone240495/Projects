from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from agent.banking_agent import BankingIntentAgent
from dashboard.dashboard import render_dashboard

load_dotenv()

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "Dev Data.csv"
HISTORY_PATH = ROOT / "results" / "classification_history.csv"
HISTORY_PATH.parent.mkdir(exist_ok=True)

st.set_page_config(page_title="Banking Intent Classification Assistant", page_icon="🏦", layout="wide")

@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH)

@st.cache_resource
def load_agent(df):
    return BankingIntentAgent(df)


def load_history():
    if HISTORY_PATH.exists():
        return pd.read_csv(HISTORY_PATH)
    return pd.DataFrame(columns=[
        "timestamp", "customer_question", "predicted_intent",
        "confidence_score", "suggested_routing_queue", "reasoning",
        "classifier", "low_confidence"
    ])


def save_result(result):
    history = load_history()
    row = pd.DataFrame([{
        "timestamp": pd.Timestamp.now().isoformat(),
        "customer_question": result["customer_question"],
        "predicted_intent": result["predicted_intent"],
        "confidence_score": result["confidence_score"],
        "suggested_routing_queue": result["suggested_routing_queue"],
        "reasoning": result["reasoning"],
        "classifier": result["classifier"],
        "low_confidence": result["low_confidence"],
    }])
    pd.concat([history, row], ignore_index=True).to_csv(HISTORY_PATH, index=False)


df = load_data()
agent = load_agent(df)

st.title("🏦 Banking Intent Classification Assistant")
st.caption("LangChain + labelled banking examples + TF-IDF retrieval + deterministic routing")

with st.sidebar:
    st.header("Dataset")
    st.metric("Training records", len(df))
    st.metric("Banking intents", df["label_text"].nunique())
    st.metric("Examples / intent", int(df.groupby("label_text").size().median()))
    st.divider()
    use_llm = bool(os.getenv("OPENAI_API_KEY")) and os.getenv("USE_LLM", "true").lower() == "true"
    st.write(f"LLM mode: **{'Enabled' if use_llm else 'TF-IDF fallback'}**")
    st.write(f"Model: **{os.getenv('OPENAI_MODEL', 'gpt-4.1-mini')}**")
    if st.button("Clear live history"):
        if HISTORY_PATH.exists():
            HISTORY_PATH.unlink()
        st.rerun()

input_tab, dashboard_tab, data_tab = st.tabs(["🔎 Classify", "📊 Dashboard", "📚 Knowledge Base"])

with input_tab:
    st.subheader("Customer question")
    question = st.text_area(
        "Enter a banking question",
        placeholder="Example: I transferred money but the recipient hasn't received it yet.",
        height=120,
    )

    examples = [
        "My card payment was declined at a shop.",
        "I don't recognise a cash withdrawal.",
        "How long does an international transfer take?",
        "I forgot my passcode and cannot access the app.",
        "The cash machine gave me the wrong amount.",
    ]
    selected = st.selectbox("Or try an example", [""] + examples)
    if selected:
        question = selected

    if st.button("Classify Intent", type="primary", use_container_width=True):
        if not question.strip():
            st.warning("Please enter a customer question.")
        else:
            with st.spinner("Classifying..."):
                result = agent.classify(question)
            save_result(result)

            st.success("Classification complete")
            a, b, c = st.columns(3)
            a.metric("Predicted Intent", result["predicted_intent"])
            b.metric("Confidence", f"{result['confidence_score']:.1%}")
            c.metric("Routing Queue", result["suggested_routing_queue"])

            if result["low_confidence"]:
                st.warning("Low confidence: routed to General Support / Human Review.")

            st.write("**Reasoning:**", result["reasoning"])
            st.write("**Classifier:**", result["classifier"])

            with st.expander("Retrieved knowledge-base examples"):
                st.dataframe(pd.DataFrame(result["retrieved_examples"]), use_container_width=True, hide_index=True)

            with st.expander("Top candidate intents"):
                st.dataframe(pd.DataFrame(result["top_intents"]), use_container_width=True, hide_index=True)

with dashboard_tab:
    render_dashboard(load_history(), df)

with data_tab:
    st.subheader("Banking Intent Knowledge Base")
    search = st.text_input("Search customer examples or intent")
    view = df.copy()
    if search:
        mask = view["text"].str.contains(search, case=False, na=False) | view["label_text"].str.contains(search, case=False, na=False)
        view = view[mask]
    st.dataframe(view, use_container_width=True, hide_index=True)
