# Banking Intent Classification Assistant

A Streamlit + LangChain banking intent classification agent using the supplied `Dev Data.csv` dataset.

## What it does

- Classifies customer questions into the 77 banking intents in the dataset.
- Retrieves similar labelled examples with TF-IDF.
- Optionally asks an OpenAI model through LangChain to make the final structured classification.
- Produces a confidence score.
- Applies deterministic routing rules.
- Sends low-confidence cases to `General Support / Human Review`.
- Stores live classifications in `results/classification_history.csv`.
- Provides a Streamlit intent-volume and routing dashboard.
- Includes a baseline evaluation script and unit tests.

## 1. Create environment

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

## 2. Install

```bash
pip install -r requirements.txt
```

## 3. Configure LLM

Copy `.env.example` to `.env` and set:

```env
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4.1-mini
USE_LLM=true
CONFIDENCE_THRESHOLD=0.65
TOP_K_EXAMPLES=5
```

If no API key is supplied, the app automatically works in TF-IDF fallback mode.

## 4. Run

```bash
streamlit run app.py
```

## 5. Evaluate the baseline

```bash
python -m evaluation.evaluate
```

This creates:

- `results/classification_report.json`
- `results/confusion_matrix.csv`

## 6. Test

```bash
pytest -q
```

## Architecture

Customer question -> TF-IDF retrieval -> LangChain structured classification -> confidence threshold -> deterministic routing -> history -> Streamlit dashboard.

The CSV is the knowledge base. Routing is kept outside the LLM so the operational queue cannot be freely invented by the model.
