from pathlib import Path
import pandas as pd

from classifier.tfidf_classifier import TfidfIntentClassifier
from routing.routing_rules import get_queue

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "Dev Data.csv"


def test_dataset_shape_and_columns():
    df = pd.read_csv(DATA)
    assert set(["text", "label", "label_text"]).issubset(df.columns)
    assert len(df) == 3080
    assert df["label_text"].nunique() == 77


def test_classifier_returns_valid_intent():
    df = pd.read_csv(DATA)
    clf = TfidfIntentClassifier(df)
    result = clf.predict("My card payment was declined")
    assert result["predicted_intent"] in set(df["label_text"])
    assert 0 <= result["confidence_score"] <= 1


def test_routing_fallback():
    assert get_queue("not_a_real_intent") == "General Support / Human Review"
